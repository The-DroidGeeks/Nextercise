package com.example.nextercise;

public class ExerciseAdapter {
}
